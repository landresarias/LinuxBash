#!/bin/bash

#The weather in a selected city
read city
if [ $# -ne 1 ]
then
    set $city
else
    set paris
fi
curl wttr.in/$1?0

