#!/bin/bash

read folderName
mkdir $folderName 
mkdir $folderName/assets
mkdir $folderName/assets/images
mkdir $folderName/css 
mkdir $folderName/js 
cp ./LinuxProj_Luis_2022/Index.html $folderName/Index.html 
cp ./LinuxProj_Luis_2022/css/App.css $folderName/css/App.css 
cp ./LinuxProj_Luis_2022/js/App.js $folderName/js/App.js
cp ./LinuxProj_Luis_2022/assets/images/Ubuntu3.jpg $folderName/assets/images/Ubuntu.jpg

echo `ls -aF` "📂"
